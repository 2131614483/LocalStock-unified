# daily-stock-pick skill 打包（2026-08-12）

每日选股 skill 完整运行包（SKILL.md + 依赖脚本 + 排错经验）。

## 安装
1. 将 SKILL.md 放回 `C:/Users/he/.claude/skills/daily-stock-pick/`
2. 将 scripts/ 下的脚本放回项目 `scripts/` 目录（或覆盖同名文件）
3. 依赖系统 Python311（baostock 可选，腾讯/新浪回填仅需 urllib）

## 运行
- skill 触发：用户说"选股/今天选什么股" → 按 SKILL.md 第 1~4 步执行
- 数据同步（默认腾讯/新浪，baostock 备选）：`python scripts/sync_gui.py --silent`
- 腾讯/新浪回填：`python scripts/backfill_daily_tx_sina.py`
- baostock 增量：`python scripts/update-daily-baostock.py`

## 排错
见 `文档/数据同步排错经验.md`（baostock 故障、探针 bug、腾讯/新浪回填口径）。
