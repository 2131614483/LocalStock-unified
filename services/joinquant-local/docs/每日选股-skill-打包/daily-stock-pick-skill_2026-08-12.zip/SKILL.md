---
name: daily-stock-pick
description: 每日选股。当用户说"选股"、"今天选什么股"、"每日选股"、"帮我看看今天的股票"、"pick stocks"、"今日推荐"、"选股报告"时使用。完整流程：检查/同步数据 → 多因子打分生成 top-N 报告 → 腾讯/新浪抓实时行情补解读 → 写亮点点评到 Obsidian。
---

# 每日选股（daily-stock-pick）

基于本地全量 A 股数据（CSMAR 全量 + 腾讯/新浪每日增量为主、baostock 备选）做**多因子截面打分选股**，结果写入 Obsidian 并附解读。**手动运行**——用户说触发词即执行。

## 工作流（按顺序执行，不要跳步）

### 第 1 步：先同步数据（同步完成后再跑因子，不可跳过）

**原则：先真正把本地数据同步到最新，再进第 2 步跑因子。** 同步源优先级：**腾讯/新浪（默认，稳定免登录）→ baostock（备选，补日历/指数口径）**，与 `sync_gui.py` 一致。

1. **主同步：腾讯/新浪回填**（`backfill_daily_tx_sina.py`，纯 urllib 无需 baostock，全市场 ~6 分钟，动态补本地最新之后所有缺失日）：
   ```bash
   C:/Users/he/AppData/Local/Programs/Python/Python311/python.exe \
     "D:/pythonpro/聚宽-local/scripts/backfill_daily_tx_sina.py"
   ```
   - 打印「本地数据已到 …，无需回填」→ 数据已最新，直接第 2 步。
   - 打印「完成: 新增 X 行, 失败 N 只, 最新 …」→ **同步完成**，进入第 2 步。
2. **备选：baostock 补口径**（`update-daily-baostock.py`，补 `trade_calendar`/`index_daily`/股票名称，使报告 1.1 指数表有数据；baostock 故障时跳过不阻塞）：
   ```bash
   C:/Users/he/AppData/Local/Programs/Python/Python311/python.exe \
     "D:/pythonpro/聚宽-local/scripts/update-daily-baostock.py"
   ```
   - 打印「无新交易日」/「baostock 数据未更新」/「登录失败」→ 跳过，用第 3 步腾讯指数补大盘。
   - baostock 服务端故障（登录/查询反复失败或 `query_trade_dates` 行迭代无超时挂起，见 `docs/project-docs/数据同步排错经验.md`）→ **不要死等**，跳过直接进第 2 步。
3. 校验同步结果：`check_data_fresh.py` 输出应等于最近交易日（如 `2026-08-11`）。
4. **环境限时兜底**：腾讯/新浪回填全市场 ~6 分钟（6 线程）通常不会超时；baostock 增量约 40 分钟（遍历全部股票补缺失日），本环境后台进程约 5 分钟被强杀（0xC000013A Ctrl+C）：
   - baostock 被限时杀 → 删残留锁 `data/sync.lock`，用 `--max-stocks` 分批续跑，**每批跑到正常结束**（锁自动释放）再跑下一批：
     ```bash
     python scripts/update-daily-baostock.py --max-stocks 2500 --delay 0.05  # 第一批
     python scripts/update-daily-baostock.py --max-stocks 5973 --delay 0.05  # 断点续传，已同步的自动跳过
     ```
   - 注意：`daily_stock_pick.py` 只取「行数≥4000 的完整交易日」，**部分同步不会更新数据日期**——必须等到目标交易日行数达标。
5. 说明：`sync_quick.py` 只是「探针 + 后台异步启动、不等它」的快速检查（已修复探针结论被 baostock `login/logout` stdout 干扰的 bug；探针须覆盖本地最新之后的**整个区间**，只查最新一天会漏同步），**不适合"先同步再跑因子"**——本步主同步用 `backfill_daily_tx_sina.py`。
6. 数据确实已最新但仍想补当日行情 → 用第 3 步腾讯实时行情。同步永远无法覆盖当日盘中/当日收盘（数据源次日才发布）。

### 第 2 步：生成 top-N 报告

```bash
C:/Users/he/AppData/Local/Programs/Python/Python311/python.exe \
  "D:/pythonpro/聚宽-local/scripts/daily_stock_pick.py" --strategy smallcap
```

- 生成 `docs/project-docs/每日选股/每日选股_YYYY-MM-DD.md` 与 Obsidian「量化回测平台/每日选股/」同名文件（含**一~九节**：市场概况 / 方案方法与**因子定义与公式** / top-50 因子明细 / 组合画像 / 前 10 因子百分位 / 口径风险 / **基本面与估值快照（腾讯实时 PE/PB/市值 + CSMAR 财务）** / **技术面辅助图（布林带+海龟通道+组合净值）** / **因子诊断与优化建议**；图片存 `每日选股/images/` 两处）。**文件名用当前系统日期**（非数据日期），每天跑一次即一个新文件；数据日期标注在报告头部。
- 自动联动：报告生成时会调 `fetch_fundamental.py`（腾讯实时估值 + CSMAR 财务快照）、`chart_strategies.py`（画布林带/海龟/当日表现/组合净值图）、`optimize_factors.py`（历史名单追踪 + 因子 IC 诊断 + 月度权重校验），任一失败不阻塞报告（降级为提示行）。
- 换方案/选股数：`--strategy value|smallcap30|multifactor`、`--n 30`、`--date YYYY-MM-DD`、`--write-report 0`。

方案（`scripts/validate_daily_schemes.py` 历史验证 2018-2026，102 个月，含交易成本）：

| 方案 | 权重 | N | 总收益 | 夏普 |
|------|------|---|--------|------|
| `smallcap`（默认） | bp0.3+ep0.2+roe0.15+毛利0.1+现金流0.1+低波0.15+ln_cap0.10 | 50 | **+12.8%** | +0.02 |
| `smallcap30` | 同 smallcap 但 N30（更集中，回测最好） | 30 | +23.2% | +0.07 |
| `multifactor` | bp0.3+ep0.2+roe0.15+毛利0.1+现金流0.1+低波0.15 | 50 | +4.9% | -0.03 |
| `value` | bp0.6+ep0.4 | 30 | -1.2% | -0.05 |

### 第 3 步：抓实时行情 + 大盘指数 + 财经要闻（纯 HTTP，无 DeepSeek）

从报告 top-10 提取股票代码，跑：

```bash
C:/Users/he/AppData/Local/Programs/Python/Python311/python.exe \
  "D:/pythonpro/聚宽-local/scripts/fetch_realtime.py" "600269,000726,600639,600502,600938,000498,000900,600694,600941,600020" 6
```

- 输出四块：**大盘指数**（上证/沪深300/深成/创业板/上证50，腾讯，含最新交易日）+ **top-10 实时行情**（腾讯/新浪）+ **个股新闻**（腾讯，前 5 只各 3 条：融资/业绩/研报/催化）+ **财经要闻**（新浪）。
- 数据源免费免登录、本机直连；**原始数据直接给 Claude 解读**——不用 DeepSeek、不用浏览器。
- 抓取失败/超时 → **跳过本步**，用纯因子解读，不阻塞。

### 第 4 步：写解读（追加到 Obsidian 报告）

读完第 2 步报告（一~九节） + 第 3 步实时数据（大盘指数/行情/个股新闻/要闻）后，用文件追加，在报告末尾写 **`## 十、Claude 亮点点评`** 段落（脚本已生成 一~九 节，报告是编号结构，跟进编号）。结构：

1. **7.1 今日市场环境**：引用第 3 步大盘指数表，用一两句点评当日风格（价值 vs 成长、大盘 vs 小盘），关联要闻。
2. **7.2 组合画像**：引用第 2 步「四、组合画像」，一句话概括组合特征（如"深度价值+低波+小市值"）。
3. **7.3 今日表现**：top-10 实时涨跌表，注明相对大盘超额、是否为盘中实时。
4. **7.4 逐票深度分析（top 5，最重要）**：每只票写一段**详细文字分析**，结合因子百分位 + PE/PB + **个股新闻**：
   - **公司主业/定位**：一句话说清这公司做什么、凭什么入选（如"区域性收费高速，现金流稳定"）。
   - **估值与质量**：bp/ep/roe/毛利/现金流百分位 + PE/PB(估)，说明"便宜在哪里、质量如何"。
   - **最新新闻/催化**：引用第 3 步该股新闻的要点（如"华创强推目标价5.71元"、"受益国际油价走高"），说明是什么在驱动或压制。
   - **风险点**：一句话提示该股特有风险（如"Q1 汇兑拖累利润"、"市值推算失真"）。
   - **结论句**：一句话给判断（防御/弹性/观察）。
5. **7.5 操作建议与风险**（必须写）：
   - **动量在 A 股反向**：不要因近期涨幅加仓；方案不含动量因子。
   - 小市值波动大、单票仓位别太重；名单是「当日截面快照」，**不构成调仓指令**；建议月度调仓、等权持有、单票止损参考 -8%。
   - 明确标注数据日期（本地因子数据日期 vs 实时行情日期，滞后时说明）。
   - PE/PB 为估算，baostock 段市值推算可能失真（如中国海油），勿单看估值数字；**用第七节腾讯实时 PE/PB/市值交叉校验**（口径不同，腾讯用其财务模型）。
6. **幂等**：若报告已含 `## 十、Claude 亮点点评`，覆盖更新该段，不要重复追加。
7. **与昨日对比**（可选）：若 Obsidian「每日选股/」有上一份报告，列出新进/掉出 top-50 的票。

## 口径说明（为什么可信）

- 因子定义单一来源 `scripts/factor_registry.json`，研究管线（pandas）与生产引擎（纯标准库）共用，`verify_factor_consistency.py` 校验两轨偏差 ≤0.001。
- **无未来函数三铁律**：基本面用「报告期 + 4 个月滞后」；动量 skip 最近 20 交易日；股票池剔除 ST/涨跌停/停牌/次新(<120日)/B股/北交所/金融股。
- 打分先 [1%,99%] 缩尾再 z-score（压制极端值），方向显式应用——与 `validate_daily_schemes.py` 一致。
- 名称级兜底：baostock 增量段 trade_status 不标 ST，脚本按名称剔除 ST 与短名金融（张家港行/中国银河/中信建投/湘财股份/东方财富）。
- 数据完整性保护：`daily_stock_pick.py` 只取「行数≥4000 的完整交易日」，不用半截数据。

## 已知边界

- **数据源优先级：腾讯/新浪为主（稳定免登录）、baostock 备选**（补 `trade_calendar`/`index_daily`/名称）。腾讯/新浪回填全市场 ~6 分钟；baostock 增量约 40 分钟且常被环境限时杀、服务端间歇性故障（`query_trade_dates` 行迭代无超时挂起/连接失败/login 10002007）——故障时跳过，用第 3 步腾讯指数补大盘。排错详见 `docs/project-docs/数据同步排错经验.md`。
- `scripts/strategies/*.py` 生产策略的 `rank_normalize` 未乘方向、未缩尾（vol_60d 被当正向）——引擎侧待修 bug，**每日选股脚本不受影响**。
- baostock 段无 B 股/北交所；`high/low` 全 NULL，无振幅类因子。
- 若 `data/research_panel.pkl` 缺失，先跑 `python scripts/factor_research.py` 重建（`validate_daily_schemes.py` 依赖它）。

## 可选的定时自动化（用户需要时再开）

- 手动跑即可；若要定时：数据同步任务 `QuantBacktestDataSync`（18:00，baostock）保留。
- 曾做过 `claude -p` 无头任务 + 会话内定时（`CronCreate`），因本环境会强制终止后台进程（0xC000013A Ctrl+C）已撤销，**不建议再启用**。
